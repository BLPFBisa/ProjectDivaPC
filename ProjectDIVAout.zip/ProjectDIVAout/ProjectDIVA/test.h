#ifndef __TestH__
#define __TestH__


ID3DXFont* Font = 0;
GameCore core;
bool Keys[256] = {0};



#endif