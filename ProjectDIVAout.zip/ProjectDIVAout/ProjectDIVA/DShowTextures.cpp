//-----------------------------------------------------------------------------
// File: DShowTextures.cpp
//
// Desc: DirectShow sample code - adds support for DirectShow videos playing 
//       on a DirectX 9.0 texture surface. Turns the D3D texture tutorial into 
//       a recreation of the VideoTex sample from previous versions of DirectX.
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//-----------------------------------------------------------------------------

#include "DShowTextures.h"
#include "VideoEngine.h"

D3DFORMAT			g_TextureFormat;	// Texture format
GUID				g_MediaFormat;		// GUID of media format

//-----------------------------------------------------------------------------
// CTextureRenderer constructor
//-----------------------------------------------------------------------------
CTextureRenderer::CTextureRenderer( LPUNKNOWN pUnk, HRESULT *phr )
: CBaseVideoRenderer(__uuidof(CLSID_TextureRenderer), 
					 NAME("Texture Renderer"), pUnk, phr),
					 m_bUseDynamicTextures(FALSE)
{
	// Store and AddRef the texture for our use.
	ASSERT(phr);
	if (phr)
		*phr = S_OK;
}

CTextureRenderer::~CTextureRenderer()
{
	// Do nothing
}

HRESULT CTextureRenderer::CheckMediaType(const CMediaType *pmt)
{
	HRESULT   hr = E_FAIL;
	VIDEOINFO *pvi=0;

	CheckPointer(pmt,E_POINTER);

	// Reject the connection if this is not a video type
	if( *pmt->FormatType() != FORMAT_VideoInfo ) {
		return E_INVALIDARG;
	}

	// Obtain video format
	pvi = (VIDEOINFO *)pmt->Format();

	// Support 32-bit video format in preference to 24-bit as 32-bit is faster
	if(IsEqualGUID( *pmt->Type(), MEDIATYPE_Video)){
		if(IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB32)){
			g_MediaFormat = MEDIASUBTYPE_RGB32;
			hr = S_OK;
		}else if(IsEqualGUID( *pmt->Subtype(), MEDIASUBTYPE_RGB24)){
			g_MediaFormat = MEDIASUBTYPE_RGB24;
			hr = S_OK;
		}
	}

	return hr;
}

HRESULT CTextureRenderer::SetMediaType(const CMediaType *pmt)
{
	HRESULT hr;

	UINT uintWidth = 2;
	UINT uintHeight = 2;

	// Retrive the size of this media type
	D3DCAPS9 caps;
	VIDEOINFO *pviBmp;                      // Bitmap info header
	pviBmp = (VIDEOINFO *)pmt->Format();

	m_lVidWidth  = pviBmp->bmiHeader.biWidth;
	m_lVidHeight = abs(pviBmp->bmiHeader.biHeight);
	if(IsEqualGUID(g_MediaFormat,MEDIASUBTYPE_RGB32))
		m_lVidPitch  = m_lVidWidth * 4;
	else
		m_lVidPitch  = (m_lVidWidth * 3 + 3) & ~(3); // We are forcing RGB24

	// here let's check if we can use dynamic textures
	ZeroMemory( &caps, sizeof(D3DCAPS9));
	hr = base::Device->GetDeviceCaps( &caps );
	if( caps.Caps2 & D3DCAPS2_DYNAMICTEXTURES )
	{
		m_bUseDynamicTextures = TRUE;
	}

	// For efficiency, do not use non-power-of-2 texture size
	while( (LONG)uintWidth < m_lVidWidth )
	{
		uintWidth = uintWidth << 1;
	}
	while( (LONG)uintHeight < m_lVidHeight )
	{
		uintHeight = uintHeight << 1;
	}

	// Create the texture that maps to this media type
	hr = E_UNEXPECTED;

	if(g_pTexture)
	{
		g_pTexture->Release();
		g_pTexture = NULL;
	}
	hr = base::Device->CreateTexture(uintWidth, uintHeight, 1, 0, 
		D3DFMT_X8R8G8B8,D3DPOOL_MANAGED,
		&g_pTexture, NULL);

	if( FAILED(hr))
	{
		Msg(TEXT("Could not create the D3DX texture!  hr=0x%x"), hr);
		return hr;
	}

	// CreateTexture can silently change the parameters on us
	D3DSURFACE_DESC ddsd;
	ZeroMemory(&ddsd, sizeof(ddsd));

	if ( FAILED( hr = g_pTexture->GetLevelDesc( 0, &ddsd ) ) ) {
		Msg(TEXT("Could not get level Description of D3DX texture! hr = 0x%x"), hr);
		return hr;
	}


	CComPtr<IDirect3DSurface9> pSurf; 

	if (SUCCEEDED(hr = g_pTexture->GetSurfaceLevel(0, &pSurf)))
		pSurf->GetDesc(&ddsd);

	// Save format info
	g_TextureFormat = ddsd.Format;

	if (g_TextureFormat != D3DFMT_X8R8G8B8 &&
		g_TextureFormat != D3DFMT_A1R5G5B5) {
			Msg(TEXT("Texture is format we can't handle! Format = 0x%x"), g_TextureFormat);
			return VFW_E_TYPE_NOT_ACCEPTED;
	}

	return S_OK;
}

HRESULT CTextureRenderer::LoadTexture()
{
	// If video image is not updated (slow FPS), don't waste time copying the same texture again
	if(bBufferRefresh){
		bBufferRefresh = false;
	}else return S_OK;

	if(g_pTexture==NULL)
		return S_OK;

	BYTE  *pBmpBuffer,*pTxtBuffer; // Bitmap buffer, texture buffer
	LONG  lTxtPitch;                // Pitch of bitmap, texture

	BYTE  * pbS = NULL;
	DWORD * pdwS = NULL;
	DWORD * pdwD = NULL;
	UINT row, col, dwordWidth;

	CheckPointer(g_pTexture,E_UNEXPECTED);
	pBmpBuffer = pBuffer;

	// Lock the Texture
	D3DLOCKED_RECT d3dlr;
	if( m_bUseDynamicTextures )
	{
		if( FAILED(g_pTexture->LockRect(0, &d3dlr, 0, D3DLOCK_DISCARD)))
			return E_FAIL;
	}
	else
	{
		if (FAILED(g_pTexture->LockRect(0, &d3dlr, 0, 0)))
			return E_FAIL;
	}

	// Get the texture buffer & pitch
	pTxtBuffer = static_cast<byte *>(d3dlr.pBits);
	lTxtPitch = d3dlr.Pitch;

	// Copy the bits    
	if (g_TextureFormat == D3DFMT_X8R8G8B8) 
	{
		if(IsEqualGUID(g_MediaFormat,MEDIASUBTYPE_RGB32)){
			// Copy 32-bit video image into 32-bit texture buffer, this is faster
			pTxtBuffer += lTxtPitch*(UINT)m_lVidHeight;
			for( row=0; row<(UINT)m_lVidHeight; row++ ){
				pTxtBuffer  -= lTxtPitch;
				memcpy(pTxtBuffer,pBmpBuffer,m_lVidWidth<<2);
				pBmpBuffer  += m_lVidPitch;
			}
		}else{
			// Instead of copying data bytewise, we use DWORD alignment here.
			// We also unroll loop by copying 4 pixels at once.
			//
			// original BYTE array is [b0][g0][r0][b1][g1][r1][b2][g2][r2][b3][g3][r3]
			//
			// aligned DWORD array is     [b1 r0 g0 b0][g2 b2 r1 g1][r3 g3 b3 r2]
			//
			// We want to transform it to [ff r0 g0 b0][ff r1 g1 b1][ff r2 g2 b2][ff r3 b3 g3]
			// below, bitwise operations do exactly this.

			dwordWidth = m_lVidWidth / 4; // aligned width of the row, in DWORDS
			// (pixel by 3 bytes over sizeof(DWORD))

			pTxtBuffer += lTxtPitch*(UINT)m_lVidHeight;

			for( row = 0; row< (UINT)m_lVidHeight; row++)
			{
				pTxtBuffer -= lTxtPitch;

				pdwS = ( DWORD*)pBmpBuffer;
				pdwD = ( DWORD*)pTxtBuffer;

				for( col = 0; col < dwordWidth; col ++ )
				{
					pdwD[0] =  pdwS[0] | 0xFF000000;
					pdwD[1] = ((pdwS[1]<<8)  | 0xFF000000) | (pdwS[0]>>24);
					pdwD[2] = ((pdwS[2]<<16) | 0xFF000000) | (pdwS[1]>>16);
					pdwD[3] = 0xFF000000 | (pdwS[2]>>8);
					pdwD +=4;
					pdwS +=3;
				}

				// we might have remaining (misaligned) bytes here
				pbS = (BYTE*) pdwS;
				for( col = 0; col < (UINT)m_lVidWidth % 4; col++)
				{
					*pdwD = 0xFF000000     |
						(pbS[2] << 16) |
						(pbS[1] <<  8) |
						(pbS[0]);
					pdwD++;
					pbS += 3;           
				}

				pBmpBuffer  += m_lVidPitch;

			}// for rows
		}
	}
	else if (g_TextureFormat == D3DFMT_A1R5G5B5) 
	{
		UINT bmpBufferInc = (IsEqualGUID(g_MediaFormat,MEDIASUBTYPE_RGB32)?4:3);
		for(int y = 0; y < m_lVidHeight; y++ ) 
		{
			BYTE *pBmpBufferOld = pBmpBuffer;
			BYTE *pTxtBufferOld = pTxtBuffer;   

			for (int x = 0; x < m_lVidWidth; x++) 
			{
				*(WORD *)pTxtBuffer = (WORD)
					(0x8000 +
					((pBmpBuffer[2] & 0xF8) << 7) +
					((pBmpBuffer[1] & 0xF8) << 2) +
					(pBmpBuffer[0] >> 3));

				pTxtBuffer += 2;
				pBmpBuffer += bmpBufferInc;
			}

			pBmpBuffer = pBmpBufferOld + m_lVidPitch;
			pTxtBuffer = pTxtBufferOld + lTxtPitch;
		}
	}

	// Unlock the Texture
	if (FAILED(g_pTexture->UnlockRect(0)))
		return E_FAIL;

	return S_OK;
}

HRESULT CTextureRenderer::DoRenderSample( IMediaSample * pSample )
{
	BYTE  *pBmpBuffer;

	CheckPointer(pSample,E_POINTER);
	CheckPointer(g_pTexture,E_UNEXPECTED);

	// Get the video bitmap buffer
	pSample->GetPointer( &pBmpBuffer );
	int size = pSample->GetSize();
	memcpy(pBuffer,pBmpBuffer,sizeof(BYTE)*size);

	// Notify the D3D renderer that the video image has changed, so need to do copying
	bBufferRefresh = true;

	/*	Don't copy video image into D3D texture now, the video may have a much higher FPS,
	more than 1 video frame may have arrived for 1 frame of D3D rendering update,
	so do the video image copying only when on demand! */

	return S_OK;
}

//-----------------------------------------------------------------------------
// Msg: Display an error message box if needed
//-----------------------------------------------------------------------------
void Msg(TCHAR *szFormat, ...)
{
	TCHAR szBuffer[1024];  // Large buffer for long filenames or URLs
	const size_t NUMCHARS = sizeof(szBuffer) / sizeof(szBuffer[0]);
	const int LASTCHAR = NUMCHARS - 1;

	// Format the input string
	va_list pArgs;
	va_start(pArgs, szFormat);

	// Use a bounded buffer size to prevent buffer overruns.  Limit count to
	// character size minus one to allow for a NULL terminating character.
	_vsntprintf(szBuffer, NUMCHARS - 1, szFormat, pArgs);
	va_end(pArgs);

	// Ensure that the formatted string is NULL-terminated
	szBuffer[LASTCHAR] = TEXT('\0');

	MessageBox(NULL, szBuffer, TEXT("DirectShow Texture3D9 Sample"), 
		MB_OK | MB_ICONERROR);
}


